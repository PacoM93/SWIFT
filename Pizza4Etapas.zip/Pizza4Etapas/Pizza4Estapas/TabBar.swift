//
//  TabBar.swift
//  Pizza4Estapas
//
//  Created by Francisco Montes Fonseca on 10/12/17.
//  Copyright © 2017 COURSERA. All rights reserved.
//

import UIKit

class TabBar: UITabBarController {

    
    var tamaño: String = "Sin selección"
    var masa: String = "Sin selección"
    var queso: String = "Sin selección"
    var ingredientes: [String] = []
//    var Ingredientes: [String] = "Sin Selección"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }



}
